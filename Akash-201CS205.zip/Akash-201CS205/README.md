For the exploratory data analysis of the dataset, I imported pandas and numpy. I read the dataset and used functions like head(), shape, info(), describe() and corr() on it to get an idea of the data.

For preprocessing it, I just made the representation look neater by showing only the first decimal place. I also scaled down the column "median_housing_value" so that its value is not too large in comparison with the other columns.

To build the model, I installed TensorFlow and imported it. I then defined functions to build and train the model. I also called these functions and tuned the hyperparameters for the same. I built the model to predict "median_housing_value" using the feature "median_income". Then I compared the predicted values with the actual ones for the first 10 data. The predictions were good in most cases considering the fact that a single feature having a correlation of less than 0.7 was used to build the model.

I just started to learn ML recently. I am currently doing an ML Recommender System project for ACM. I am doing a crash course by Google for learning ML and some of the codes I used have been taken from there. 